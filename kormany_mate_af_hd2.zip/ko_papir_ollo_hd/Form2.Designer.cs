﻿namespace ko_papir_ollo_hd
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.ujjatekButton = new System.Windows.Forms.Button();
            this.koButton = new System.Windows.Forms.Button();
            this.papirButton = new System.Windows.Forms.Button();
            this.olloButton = new System.Windows.Forms.Button();
            this.jatekosLabel = new System.Windows.Forms.Label();
            this.enemyKo = new System.Windows.Forms.Label();
            this.enemyOllo = new System.Windows.Forms.Label();
            this.enemyPapir = new System.Windows.Forms.Label();
            this.eredmenyLabel = new System.Windows.Forms.Label();
            this.gepLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ujjatekButton
            // 
            this.ujjatekButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ujjatekButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ujjatekButton.Location = new System.Drawing.Point(761, 282);
            this.ujjatekButton.Name = "ujjatekButton";
            this.ujjatekButton.Size = new System.Drawing.Size(109, 33);
            this.ujjatekButton.TabIndex = 0;
            this.ujjatekButton.Text = "Új játék";
            this.ujjatekButton.UseVisualStyleBackColor = false;
            this.ujjatekButton.Click += new System.EventHandler(this.ujjatekButton_Click);
            // 
            // koButton
            // 
            this.koButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("koButton.BackgroundImage")));
            this.koButton.Location = new System.Drawing.Point(23, 424);
            this.koButton.Name = "koButton";
            this.koButton.Size = new System.Drawing.Size(224, 185);
            this.koButton.TabIndex = 1;
            this.koButton.UseVisualStyleBackColor = true;
            this.koButton.Click += new System.EventHandler(this.koButton_Click);
            // 
            // papirButton
            // 
            this.papirButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("papirButton.BackgroundImage")));
            this.papirButton.Location = new System.Drawing.Point(270, 341);
            this.papirButton.Name = "papirButton";
            this.papirButton.Size = new System.Drawing.Size(178, 268);
            this.papirButton.TabIndex = 2;
            this.papirButton.UseVisualStyleBackColor = true;
            this.papirButton.Click += new System.EventHandler(this.papirButton_Click);
            // 
            // olloButton
            // 
            this.olloButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("olloButton.BackgroundImage")));
            this.olloButton.Location = new System.Drawing.Point(482, 351);
            this.olloButton.Name = "olloButton";
            this.olloButton.Size = new System.Drawing.Size(178, 249);
            this.olloButton.TabIndex = 3;
            this.olloButton.UseVisualStyleBackColor = true;
            this.olloButton.Click += new System.EventHandler(this.olloButton_Click);
            // 
            // jatekosLabel
            // 
            this.jatekosLabel.AutoSize = true;
            this.jatekosLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.jatekosLabel.Location = new System.Drawing.Point(788, 367);
            this.jatekosLabel.Name = "jatekosLabel";
            this.jatekosLabel.Size = new System.Drawing.Size(16, 18);
            this.jatekosLabel.TabIndex = 5;
            this.jatekosLabel.Text = "0";
            // 
            // enemyKo
            // 
            this.enemyKo.Image = ((System.Drawing.Image)(resources.GetObject("enemyKo.Image")));
            this.enemyKo.Location = new System.Drawing.Point(23, 73);
            this.enemyKo.Name = "enemyKo";
            this.enemyKo.Size = new System.Drawing.Size(224, 185);
            this.enemyKo.TabIndex = 6;
            // 
            // enemyOllo
            // 
            this.enemyOllo.Image = ((System.Drawing.Image)(resources.GetObject("enemyOllo.Image")));
            this.enemyOllo.Location = new System.Drawing.Point(482, 9);
            this.enemyOllo.Name = "enemyOllo";
            this.enemyOllo.Size = new System.Drawing.Size(178, 249);
            this.enemyOllo.TabIndex = 7;
            // 
            // enemyPapir
            // 
            this.enemyPapir.Image = ((System.Drawing.Image)(resources.GetObject("enemyPapir.Image")));
            this.enemyPapir.Location = new System.Drawing.Point(270, 9);
            this.enemyPapir.Name = "enemyPapir";
            this.enemyPapir.Size = new System.Drawing.Size(178, 268);
            this.enemyPapir.TabIndex = 8;
            // 
            // eredmenyLabel
            // 
            this.eredmenyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.eredmenyLabel.Location = new System.Drawing.Point(301, 282);
            this.eredmenyLabel.Name = "eredmenyLabel";
            this.eredmenyLabel.Size = new System.Drawing.Size(147, 32);
            this.eredmenyLabel.TabIndex = 9;
            this.eredmenyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gepLabel
            // 
            this.gepLabel.AutoSize = true;
            this.gepLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gepLabel.Location = new System.Drawing.Point(788, 214);
            this.gepLabel.Name = "gepLabel";
            this.gepLabel.Size = new System.Drawing.Size(16, 18);
            this.gepLabel.TabIndex = 10;
            this.gepLabel.Text = "0";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(900, 621);
            this.Controls.Add(this.gepLabel);
            this.Controls.Add(this.eredmenyLabel);
            this.Controls.Add(this.enemyPapir);
            this.Controls.Add(this.enemyOllo);
            this.Controls.Add(this.enemyKo);
            this.Controls.Add(this.jatekosLabel);
            this.Controls.Add(this.olloButton);
            this.Controls.Add(this.papirButton);
            this.Controls.Add(this.koButton);
            this.Controls.Add(this.ujjatekButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kő-papír-olló";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ujjatekButton;
        private System.Windows.Forms.Button koButton;
        private System.Windows.Forms.Button papirButton;
        private System.Windows.Forms.Button olloButton;
        private System.Windows.Forms.Label jatekosLabel;
        private System.Windows.Forms.Label enemyKo;
        private System.Windows.Forms.Label enemyOllo;
        private System.Windows.Forms.Label enemyPapir;
        private System.Windows.Forms.Label eredmenyLabel;
        private System.Windows.Forms.Label gepLabel;
    }
}