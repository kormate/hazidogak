﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ko_papir_ollo_hd
{
    public partial class Form2 : Form
    {

        string[] gep_valasztas = { "ko", "papir", "ollo", "papir", "ollo", "ko", "ollo", "papir", "ko"  };

        int randomNum = 0;
        Random rnd = new Random();

        string gep;

        string jatekos;

        int jatekosPontja;
        int gepPontja;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            enemyKo.Visible = false;
            enemyOllo.Visible = false;
            enemyPapir.Visible = false;
        }

        private void koButton_Click(object sender, EventArgs e)
        {
            jatekos = "ko";

            randomNum = rnd.Next(0, gep_valasztas.Length);

            gep = gep_valasztas[randomNum];

            switch (gep)
            {
                case "ko":
                    enemyKo.Visible = true;
                    eredmenyLabel.Text = "Döntetlen";
                    break;

                case "papir":
                    enemyPapir.Visible = true;
                    eredmenyLabel.Text = "A gép nyert";
                    gepPontja += 1;
                    gepLabel.Text = gepPontja.ToString();
                    break;

                case "ollo":
                    enemyOllo.Visible = true;
                    eredmenyLabel.Text = "A játékos nyert";
                    jatekosPontja += 1;
                    jatekosLabel.Text = jatekosPontja.ToString();
                    break;
            }



            papirButton.Visible = false;
            olloButton.Visible = false;
        }

        private void papirButton_Click(object sender, EventArgs e)
        {
            jatekos = "papir";

            randomNum = rnd.Next(0, gep_valasztas.Length);

            gep = gep_valasztas[randomNum];

            switch (gep)
            {
                case "ko":
                    enemyKo.Visible = true;
                    eredmenyLabel.Text = "A játékos nyert";
                    jatekosPontja += 1;
                    jatekosLabel.Text = jatekosPontja.ToString();
                    break;

                case "papir":
                    enemyPapir.Visible = true;
                    eredmenyLabel.Text = "Döntetlen";
                    break;

                case "ollo":
                    enemyOllo.Visible = true;
                    eredmenyLabel.Text = "A gép nyert";
                    gepPontja += 1;
                    gepLabel.Text = gepPontja.ToString();
                    break;
            }


            koButton.Visible = false;
            olloButton.Visible = false;
        }

        private void olloButton_Click(object sender, EventArgs e)
        {
            jatekos = "ollo";

            randomNum = rnd.Next(0, gep_valasztas.Length);

            gep = gep_valasztas[randomNum];

            switch (gep)
            {
                case "ko":
                    enemyKo.Visible = true;
                    eredmenyLabel.Text = "A gép nyert";
                    gepPontja += 1;
                    gepLabel.Text += gepPontja.ToString();
                    break;

                case "papir":
                    enemyPapir.Visible = true;
                    eredmenyLabel.Text = "A játékos nyert";
                    jatekosPontja += 1;
                    jatekosLabel.Text = jatekosPontja.ToString();
                    break;

                case "ollo":
                    enemyOllo.Visible = true;
                    eredmenyLabel.Text = "Döntetlen";
                    break;
            }



            koButton.Visible = false;
            papirButton.Visible = false;
        }

        private void ujjatekButton_Click(object sender, EventArgs e)
        {
            koButton.Visible = true;
            papirButton.Visible = true;
            olloButton.Visible = true;

            enemyKo.Visible = false;
            enemyOllo.Visible = false;
            enemyPapir.Visible = false;

            eredmenyLabel.Text = string.Empty;
        }
    }
}
