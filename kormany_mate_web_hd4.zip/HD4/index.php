<?php 

include("front/load.php");

?>