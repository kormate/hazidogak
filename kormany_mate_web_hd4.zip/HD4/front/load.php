<?php 
include("header.php");
include("footer.php");
include("menu.php");
include("main.php");

?>