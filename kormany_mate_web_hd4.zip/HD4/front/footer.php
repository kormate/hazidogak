<div id="labreszdiv">
    
        <footer><pre>             *****
            Kormány Máté 2022.12.22
             *****
             Copyright © 2024</pre></footer>
        
    </div>
     
</body>
</html>