<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./front/css/style.css">
    <title>Karácsonyfa vásár </title></title>
</head>
<body>

    
    <div id="fejlecdiv">
        <header>Kellemes ünnepeket!</header>
    </div>
    <div id="menudiv">
       <nav>
            <span class="menuitems">*</span>
            <a href="../pages/kezdolap.php" class="menuitems">Kezdőlap</a>
            <span class="menuitems">*</span>
            <a href="rendeles.php" class="menuitems">Rendelés</a>
            <span class="menuitems">*</span>
            <a href="tortenet.php" class="menuitems">Történet</a>
            <span class="menuitems">*</span>
        </nav> 
    </div>