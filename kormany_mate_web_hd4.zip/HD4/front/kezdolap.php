<div id="tartalomdiv">

<h2 id="kezdolaph2">KARÁCSONYFA ONLINE</h2>
<h3 id="kezdolaph3">Házhoz visszük a karácsonyt</h3>

<p>
    Kényelmesen, egy kattintással az Ön otthonába varázsoljuk a karácsonyi fát. Felvesszük előrendelését, és december 10-től 24-ig bármely napon, előre egyeztetett időpontban kiszállítjuk. A szállítás ingyenes. Kérésére a fát díjmentesen befaragjuk a talpba. Amennyiben 10-e előtt rendeli meg fáját, <span id="szinezes">AJÁNDÉK</span> díszekkel kedveskedünk Önnek.
</p>

<div id="kepek">
    <img src="img/nordmann.png">
    <img src="img/ezust.png" >
    <img src="img/luc.png" >
</div>
<div id="nevek">
    <span id="nordmannnev">Nordmann fenyő</span>
    <span id="ezustnev">Ezüst fenyő</span>
    <span id="lucnev">Lucfenyő</span>
</div>

</div>