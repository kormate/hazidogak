<div id="tartalomdiv">
        <h2 id="rendelescim">Karácsonyfa rendelés</h2>
        <p>Ingyenes házhozszállítás Budapest egész területén</p>
        <form>
            <div id="nevcimlabdiv">
            <label id="nevlabel">Teljes név *</label>
            <label id="cimlabel">Cím *</label>
            </div>
            <div id="nevciminpdiv">
                <input id="nevinput" type="text"  required>
                 <input id="ciminput" type="text" required>
            </div>
            <div id="emailtelefonlabdiv">
                 <label id="emaillabel">Email *</label>
                 <label id="telefonlabel">Telefonszám *</label>
            </div>
            <div id="emailtelefoninpdiv">
            <input id="emailinput" type="email" required>
            <input id="telefoninput" type="text" required>
            </div>

                <div id="tipusmeretdiv">
                <label id="tipuslabel">Karácsonyfa típusa</label>
                <label id="meretlabel">Mérete</label>
                </div>
                
                <div id="karifatipus">
                <select>
                    <option>Nordmann fenyő (9000 Ft/méter)</option>
                    <option>Ezüst fenyő (7000 Ft/méter)</option>
                    <option>Lucfenyő (5000 Ft/méter)</option>
                </select>
                <select id="meretselect">
                    <option>Kicsi (100-140 cm)</option>
                    <option>Közepes (140-180 cm)</option>
                    <option>Nagy (180-220 cm)</option>
                    <option>Extra nagy (220-300 cm)</option>
                </select>
            </div>

            <div id="talpvagaslabel">
                <label>Karácsonyfa talpat kérek (+5000 Ft)</label>
                <label id="vagaslabel">Vágás típusa</label>
            </div>

            <div id="buttons1">
                <input type="radio" name="igennem" id="igen">Igen
                <input type="radio" name="fv" id="foldlabdas">Földlabdás/csak kis fánál +3000 Ft
            </div>

            <div id="buttons2">
                <input type="radio" name="igennem" id="nem">Nem
                <input type="radio" name="fv" id="vagott">Vágott
            </div>

            <div id="datumdiv">
                <label>Szállítás dátuma: 2023. december </label>
                <input type="number" min="1" max="24">
            </div>

            Megjegyzés
            <br>
            <textarea id="megjegyzes" cols="80" rows="7"></textarea>
            <br>
            <input type="checkbox" id="ajandek">Kérem az ajándékot
            <br>
            <input type="submit" id="rendelessub" value="Rendelés">

        </form>

    </div>