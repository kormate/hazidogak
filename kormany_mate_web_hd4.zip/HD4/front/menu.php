 <!-- <?php 
$menu_number = 0;

if (isset($_GET["p"]) && $_GET["p"] >= 0 && $_GET["p"] < count($menu))
    $menu_number = $_GET["p"];

$page = "pages/" . $menu[$menu_number] -> filename;
?> -->